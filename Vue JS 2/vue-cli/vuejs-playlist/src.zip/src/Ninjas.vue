<template>
<!-- There can only be one root component/element. So, add a div tag so there is just one container that can hold lots of different code  -->
  <div>
    <h1>List of Ninjas</h1>
    <ul>
      <li v-for="ninja in ninjas">{{ ninja }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  data () {
    return {
      ninjas: ['Yoshi', 'Mario', 'Ryu']
    }
  }
}
</script>

<!-- Using <style coped></style> means the CSS will only apply to this component. It will not take on styling to other h1 tags -->
<style scoped>
  h1 {
    color: green;
  }
</style>

