<template>
  <div>
      <h1>{{ title }}</h1>
      <!-- Can use a HTML type tag as using it here Vue.component('ninjas' -->
      <ninjas></ninjas>
  </div>
</template>

<script>
export default {
  data () {
    return {
      title: 'Ninja App'
    }
  }
}

// To register locall you would just do the following:
// import NInjas from './Ninjas.vue'
// export default {
//   components: {
//     'ninjas' : NInjas
//   },
//   data () {
//     return {
//       title: 'Ninja App'
//     }
//   }
// }
</script>

<!-- Using <style coped></style> means the CSS will only apply to this component. It will not take on styling to other h1 tags -->
<style scoped>
  h1 {
    color: blue;
  }
</style>
