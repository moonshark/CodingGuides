import Vue from 'vue'
import App from './App.vue'
import Ninjas from './Ninjas.vue'

// Register Globally. First the name of the component 'Ninjas'. Then the object we need. The object is inside of ninjas.vue.
Vue.component('ninjas', Ninjas);

new Vue({
  el: '#app',
  // Taking our root component 'App' that is importing and rendering it to #app
  render: h => h(App)
})
